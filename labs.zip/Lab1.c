/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lab1.c
 * Author: sunjiaze
 * Student Number: 1002269305
 * Created on May 15, 2017, 1:13 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * This lab calculates the sum of two mixed numbers.
 */
int main(void) {

    // declare and initialize the variables used for user inputs
    int wholeNumber1 = 0;
    int numerator1 = 0;
    int denominator1 = 0;
    int wholeNumber2 = 0;
    int numerator2 = 0;
    int denominator2 = 0;
    
    // prompt the user for two mixed numbers
    printf("Please enter first mixed number (whole number numerator denominator): ");
    scanf("%d %d %d", &wholeNumber1, &numerator1, &denominator1);
    printf("Please enter second mixed number (whole number numerator denominator): ");
    scanf("%d %d %d", &wholeNumber2, &numerator2, &denominator2);
    
    // declare and initialize the variables used for the calculation process and the program output
    int wholeNumberResult = 0;
    int numeratorResult = 0;
    int denominatorResult = 0;
    int divisionAddition = 0;
    
    // calculate the whole number, numerator and denominator parts of the output accordingly 
    denominatorResult = denominator1 * denominator2;
    divisionAddition = ((numerator1*denominator2)+(numerator2*denominator1)) / denominatorResult;
    wholeNumberResult = wholeNumber1 + wholeNumber2 + divisionAddition;
    numeratorResult = ((numerator1*denominator2)+(numerator2*denominator1)) - (divisionAddition * denominatorResult);
    
    // print the addition process and the final sum result according to the required format
    printf("\t%d\tand\t%d/%d\n",wholeNumber1,numerator1,denominator1);
    printf("+\t%d\tand\t%d/%d\n",wholeNumber2,numerator2,denominator2);
    printf("------------------------------\n");
    printf("\t%d\tand\t%d/%d",wholeNumberResult,numeratorResult,denominatorResult);
    
    
    return (EXIT_SUCCESS);
}

