/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lab2.c
 * Author: sunjiaze
 * Student Number: 1002269305
 * Created on May 18, 2017, 11:23 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>




/*
 * This function computes the resistance value of a given resistor as a function of its color bands.
 */

int main(int argc, char** argv) {
    
    char firstBand = 'a';
    char secondBand = 'a';
    char multiplier = 'a';
    char tolerance = 'a';
    
    printf("Please enter the 1st band:\n");
    scanf(" %c", &firstBand);
    
    printf("Please enter the 2nd band:\n");
    scanf(" %c", &secondBand);
    
    printf("Please enter the multiplier band:\n");
    scanf(" %c", &multiplier);
    
    printf("Please enter the tolerance band:\n");
    scanf(" %c", &tolerance);
    
    
    printf("Resistor bands: ");
    
    
    double firstBandVal = 0;
    
    
    if (firstBand == 'K' || firstBand == 'k') {
        firstBandVal = 0;
        char firstBandName[] = "Black";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'B' || firstBand == 'b'){
        firstBandVal = 1;
        char firstBandName[] = "Brown";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'R' || firstBand == 'r'){
        firstBandVal = 2;
        char firstBandName[] = "Red"; 
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'O' || firstBand == 'o'){
        firstBandVal = 3;
        char firstBandName[] = "Orange";
        printf("%s ", firstBandName);
    }
    else if(firstBand == 'E' || firstBand == 'e'){
        firstBandVal = 4;
        char firstBandName[] = "Yellow";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'G' || firstBand == 'g'){
        firstBandVal = 5;
        char firstBandName[] = "Green";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'U' || firstBand == 'u'){
        firstBandVal = 6;
        char firstBandName[] = "Blue";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'V' || firstBand == 'v'){
        firstBandVal = 7;
        char firstBandName[] = "Violet";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'Y' || firstBand == 'y'){
        firstBandVal = 8;
        char firstBandName[] = "Grey";
        printf("%s ", firstBandName);
    }
    else if (firstBand == 'W' || firstBand == 'w'){
        firstBandVal = 9;
        char firstBandName[] = "White";
        printf("%s ", firstBandName);
    }
    
    
    
    
    
    double secondBandVal = 0;
    
    
    if (secondBand == 'K' || secondBand == 'k') {
        secondBandVal = 0;
        char secondBandName[] = "Black";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'B' || secondBand == 'b'){
        secondBandVal = 1;
        char secondBandName[] = "Brown";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'R' || secondBand == 'r'){
        secondBandVal = 2;
        char secondBandName[] = "Red";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'O' || secondBand == 'o'){
        secondBandVal = 3;
        char secondBandName[] = "Orange";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'E' || secondBand == 'e'){
        secondBandVal = 4;
        char secondBandName[] = "Yellow";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'G' || secondBand == 'g'){
        secondBandVal = 5;
        char secondBandName[] = "Green";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'U' || secondBand == 'u'){
        secondBandVal = 6;
        char secondBandName[] = "Blue";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'V' || secondBand == 'v'){
        secondBandVal = 7;
        char secondBandName[] = "Violet";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'Y' || secondBand == 'y'){
        secondBandVal = 8;
        char secondBandName[] = "Grey";
        printf("%s ", secondBandName);
    }
    else if (secondBand == 'W' || secondBand == 'w'){
        secondBandVal = 9;
        char secondBandName[] = "White";
        printf("%s ", secondBandName);
    }
  
    double multiplierVal = 0;

    if (multiplier == 'K' || multiplier == 'k') {
        multiplierVal = 1;
        char multiplierName[] = "Black";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'B' || multiplier == 'b'){
        multiplierVal = 10;
        char multiplierName[] = "Brown";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'R' || multiplier == 'r'){
        multiplierVal = 100;
        char multiplierName[] = "Red";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'O' || multiplier == 'o'){
        multiplierVal = 1000;
        char multiplierName[] = "Orange";
        printf("%s ", multiplierName);        
    }
    else if (multiplier == 'E' || multiplier == 'e'){
        multiplierVal = 10000;
        char multiplierName[] = "Yellow";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'G' || multiplier == 'g'){
        multiplierVal = 100000;
        char multiplierName[] = "Green";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'U' || multiplier == 'u'){
        multiplierVal = 1000000;
        char multiplierName[] = "Blue";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'V' || multiplier == 'v'){
        multiplierVal = 10000000;
        char multiplierName[] = "Violet";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'L' || multiplier == 'l'){
        multiplierVal = 0.1;
        char multiplierName[] = "Gold";
        printf("%s ", multiplierName);
    }
    else if (multiplier == 'S' || multiplier == 's'){
        multiplierVal = 0.01;
        char multiplierName[] = "Silver";
        printf("%s ", multiplierName);
    }
    
    
    
    
    
    double toleranceVal = 0;
    
    if (tolerance == 'B' || tolerance == 'b'){
        toleranceVal = 1;
        char toleranceName[] = "Brown";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'R' || tolerance == 'r'){
        toleranceVal = 2;
        char toleranceName[] = "Red";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'G' || tolerance == 'g'){
        toleranceVal = 0.5;
        char toleranceName[] = "Green";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'U' || tolerance == 'u'){
        toleranceVal = 0.25;
        char toleranceName[] = "Blue";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'V' || tolerance == 'v'){
        toleranceVal = 0.10;
        char toleranceName[] = "Violet";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'Y' || tolerance == 'y'){
        toleranceVal = 0.05;
        char toleranceName[] = "Grey";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'L' || tolerance == 'l'){
        toleranceVal = 5;
        char toleranceName[] = "Gold";
        printf("%s\n", toleranceName);
    }
    else if (tolerance == 'S' || tolerance == 's'){
        toleranceVal = 10;
        char toleranceName[] = "Silver";
        printf("%s\n", toleranceName);
    }
    
    
   
    double resistance = 0.0;
    
    resistance = ((firstBandVal * 10) + secondBandVal) * multiplierVal;
    
    printf("Resistance: ");
    

    
    if (resistance >= 1000000) {
        char unit = 'M';
        printf("%.2lf %cOhms ", resistance/1000000, unit);
    }
    else if (resistance >= 1000) {
        char unit = 'K';
        printf("%.2lf %cOhms ", resistance/1000, unit);
    }
    else {
        printf("%.2lf Ohms ", resistance);
    }
    
    printf("+/- %.2lf%%", toleranceVal);
    
    
    
    
    
    return (EXIT_SUCCESS);
}

