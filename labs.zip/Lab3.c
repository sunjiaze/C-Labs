/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lab3.c
 * Author: sunjiaze
 * Created on May 27, 2017, 10:31 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*
 * 
 */
int main(int argc, char** argv) {
    
    int n = 0;
    double a = 0;
    double b = 0;
    srand(0);
    
    printf("Please enter the number of trials (n): ");
    scanf("%d", &n);
    
    if (n < 1) {
        return 0;
    }
    
    else {
        
        int exit = 1;
        
        while (exit) {
        
        printf("Enter the interval of integration (a b): ");
        scanf("%lf %lf", &a, &b);
        
        while (a > b) {
            printf("Invalid interval!\n");
            printf("Enter the interval of integration (a b): ");
            scanf("%lf %lf", &a, &b);    
        }



        int count = 0;
        double randomX = 0;

        for (int i = 1; i <= n; i++) {

            randomX = a + (rand() / (double) RAND_MAX) * (b-a);
            double functionY = exp(-(randomX*randomX)*0.5);
            double randomY = rand() / (double) RAND_MAX;
            if (functionY > randomY){
            count++;
            }
        }

        double probability = (double)count / (double)n;

        double estimation = probability * (b-a);


        printf("Integral of exp(-x^2/2) on [%.3lf, %.3lf] with n = %d trials is: %.3lf\n", a, b, n , estimation);

        printf("\nPlease enter the number of trials (n): ");
        scanf("%d", &n);
    
        if (n < 1) {
            exit = 0;
            printf("Exiting.");
        }
    }
        
        return (EXIT_SUCCESS);
    }
}

