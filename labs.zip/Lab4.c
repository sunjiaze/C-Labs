/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lab4.c
 * Author: user
 *
 * Created on June 1, 2017, 8:43 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*
 * 
 */
double polynomial(double x, double a, double b, double c, double d);
double derivative(double x, double a, double b, double c, double d);

int main(int argc, char** argv) {

    double a = 0.0;
    double b = 0.0;
    double c = 0.0;
    double d = 0.0;
    double xOld = 0.0;
    double xNew = 0.0;
    double precision = 0.0;
    
    printf("Enter the coefficients (a, b, c, d): ");
    scanf("%lf %lf %lf %lf", &a, &b, &c, &d);
    
    printf("Enter the initial guess for x: ");
    scanf("%lf", &xOld);
    
    printf("Enter the precision: ");
    scanf("%lf", &precision);
    
    int exit = 1;
    int count = 0;
    
    while (exit) {
        
         xNew = xOld - (polynomial(xOld, a, b, c, d)/derivative(xOld, a, b, c, d));
         count++;
         
         if (xOld > xNew) {  
            if ((xOld-xNew) < precision) {
                exit = 0;
            }
            else {
                xOld = xNew;
            }
         }
         else {
            if ((xNew-xOld) < precision) {
                exit = 0;
            }
            else {
                xOld = xNew;
            } 
         }
    }

    
    printf("f(x) = 0 at x = %.3lf\n", xNew);
    printf("Number of iterations = %d", count);
    
    return (EXIT_SUCCESS);
}

double polynomial(double x, double a, double b, double c, double d) {
    double result = 0.0;
    result = (a * pow(x,3)) + (b * pow(x,2)) + (c * x) + d;
    return result;
}

double derivative(double x, double a, double b, double c, double d) {
    double result = 0.0;
    result = (3 * a * pow(x,2)) + (2 * b * x) + c;
    return result;
}