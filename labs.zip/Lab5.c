/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Lab5.c
 * Author: user
 *
 * Created on June 5, 2017, 12:42 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

/*
 * 
 */
void encode_function(char *encode);
void decode_function(char *decode);

int main(int argc, char** argv) {
    
    char command;
    bool exit = false;
    
    do {
        
        printf("Enter command - e (encode), d (decode), q (quit): ");
        scanf(" %c", &command);
        
        if (command == 'e') {
            char encode[1024];
            printf("Enter string to encode: ");
            scanf("%s", encode);
            printf("Encoded string: ");
            encode_function(encode);
        } 
        else if (command == 'd') {
            char decode[1024];
            printf("Enter string to decode: ");
            scanf("%s", decode);
            printf("Decoded string: ");
            decode_function(decode);
            printf("\n");
        } 
        else if (command == 'q') {
            printf("Exiting.");
            exit = true;
        } 
        else {
            printf("Unknown command '%c'\n", command);
        }
    
    } while (exit == false);
    
    return (EXIT_SUCCESS);
}

void encode_function(char *encode){
    char initialChar = encode[0];
    int count = 0;
    for (int i = 0; i < strlen(encode); i++){
        if (encode[i] == initialChar) {
            count++;
            if (encode[i+1] == '\0'){
               printf("%d%c\n",count,initialChar); 
            }
        }
        else {
            printf("%d%c",count,initialChar);
            initialChar = encode[i];
            count = 1;
        }
        if ((count == 1) && (encode[i+1] == '\0') && (strlen(encode) != 1)) {
            printf("1%c\n", encode[i]);
        }
    }   
}


void decode_function(char *decode) {
    int numDigits = 0;
    char printChar = 'a';
    int numChar = 0;
    
    for (int i = 0; i < strlen(decode); i++){
        
        if (isalpha(decode[i])) {
            printChar = decode[i];
            
            for (int j = 1; j <= numDigits; j++){
                double digits;
                digits = decode[i-j] - 48; //according to ascii code
                numChar = numChar + (digits * pow(10,(j-1)));
            }
            for (int k = 1; k <= numChar; k++) {
                printf("%c", printChar);
            }
            numDigits = 0;
        }
        else {
            numChar = 0;
            numDigits++;
        }
    }        
        
}    
        
        
        
        
/*        if (isalpha(decode[i])) {
           printChar = decode[i];
           
           for (int p = numDigits; p > 0; p--){
               for (int q = (numDigits - 1), q > 0; q--) {
               numChar = numChar + pow(decode[i-q],)
           }
           }
           
           
           
           for (int j = 0; j <= numChar; j++){
                printf("%c", printChar);
                numDigits = 0;
            }
        } 
        else {
            numDigits++;
        }   
    }
    

    }

*/