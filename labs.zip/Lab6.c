
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   Lab6.c
 * Author: user
 *
 * Created on June 19, 2017, 10:50 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

/*
 *
 */
void matrix_multiplication(int **matrixA, int **matrixB, int **matrixAB, int ABrows, int ABcols, int sumTimes);
void read_matrix(char matrix[]);
void convert_array(char matrix[], int numberArray[]);
int read_rows(char matrix[]);
int read_cols(char matrix[]);
int main(int argc, char** argv) {
	
	printf("Enter matrix A:\n");
	char *matrixA = malloc(99);
	read_matrix(matrixA);
	int aRows = read_rows(matrixA);
	int aCols = read_cols(matrixA);
	
	int numberArrayA[aRows*aCols];
	//printf("%d %d\n", aRows, aCols);
 
	
	
	convert_array(matrixA,numberArrayA);
	//int matrixAOperate[aRows][aCols];
	int **matrixAOperate;
	matrixAOperate = (int**)malloc(aRows*sizeof(int*));
	for (int i = 0; i < aRows; i++){
		matrixAOperate[i] = (int*)malloc(aCols*sizeof(int));
	}
	int numArrayIndexA = 0;
	for (int row = 0; row < aRows; row++){
		for (int col = 0; col < aCols; col++){
			matrixAOperate[row][col] = numberArrayA[numArrayIndexA++];
		}
	}
	
	printf("\nMatrix A:\n");
	
	for (int row = 0; row < aRows; row++){
		for (int col = 0; col < aCols; col++){
			printf("%d", matrixAOperate[row][col]);
			if (col == aCols - 1){
				printf("\n");
			}
			else {
				printf("\t");
			}
		}
	}
	
	printf("\nEnter matrix B:\n");
	char *matrixB = malloc(99);
	read_matrix(matrixB);
	int bRows = read_rows(matrixB);
	int bCols = read_cols(matrixB);
	
	int numberArrayB[bRows*bCols];
	//printf("%d %d\n", bRows, bCols);
 
	
	
	convert_array(matrixB,numberArrayB);
	//int matrixBOperate[bRows][bCols];
	int **matrixBOperate;
	matrixBOperate= (int**)malloc(bRows*sizeof(int*));
	for (int i = 0; i < bRows; i++){
		matrixBOperate[i] = (int*)malloc(bCols*sizeof(int));
	}
	int numArrayIndexB = 0;
	for (int row = 0; row < bRows; row++){
		for (int col = 0; col < bCols; col++){
			matrixBOperate[row][col] = numberArrayB[numArrayIndexB++];
		}
	}
	
	printf("\nMatrix B:\n");
	
	for (int row = 0; row < bRows; row++){
		for (int col = 0; col < bCols; col++){
			printf("%d", matrixBOperate[row][col]);
			if (col == bCols - 1){
				printf("\n");
			}
			else {
				printf("\t");
			}
		}
	}
	
	
        if (aCols == bRows) {
        
	int **matrixAB;
	matrixAB = (int**)calloc(aRows,sizeof(int*));
	for (int i = 0; i < aRows; i++){
		matrixAB[i] = (int*)malloc(bCols*sizeof(int));
	}
	
	matrix_multiplication(matrixAOperate,matrixBOperate,matrixAB,aRows,bCols,aCols);
        printf("\nmatrixAB:\n");
	
	
	for (int i = 0; i < aRows; i++){
		for (int j = 0; j < bCols; j++){
			printf("%d\t", matrixAB[i][j]);
			if (j == (bCols - 1)) {
				printf("\n");
			}
		}
	}
	for (int i = 0; i < aRows; i++){
		free(matrixAB[i]);
		matrixAB[i] = NULL;
	}
	free(matrixAB);
	matrixAB = NULL;
        }
	else {
            printf("\nError: inner matrix dimensions do not agree!");
        }

	
	for (int i = 0; i < aRows; i++){
		free(matrixAOperate[i]);
		matrixAOperate[i] = NULL;
	}
	free(matrixAOperate);
	matrixAOperate = NULL;
	
	for (int i = 0; i < bRows; i++){
		free(matrixBOperate[i]);
		matrixBOperate[i] = NULL;
	}
	free(matrixBOperate);
	matrixBOperate = NULL;
	

	free(matrixA);
	matrixA = NULL;
	free(matrixB);
	matrixB = NULL;
	
	return (EXIT_SUCCESS);
}

void read_matrix(char matrix[]) {
	int i = 0;
	int ch;
	
	while ((ch = getchar()) != '\n') {
		
		matrix[i] = ch;
		i++;
	}
	matrix[i] = '\0';
}

int read_rows(char matrix[]){
	int rowCount = 0;
	for (int i = 0; matrix[i] != '\0'; i++){
		if (matrix[i] == ';') {
			rowCount++;
		}
	}
	return (rowCount+1);
}

int read_cols(char matrix[]){
	int colCount = 0;
	for (int i = 0; (matrix[i] != ';') && (matrix[i] != '\0'); i++){
		if (matrix[i] == ' '){
			colCount++;
		}
	}
	return (colCount+1);
}

void convert_array(char matrix[], int numberArray[]){
	int digitCount = 0;
	int number = 0;
	int numArrayIndex = 0;
	for (int i = 0; matrix[i] != '\0'; i++){
		if (isdigit(matrix[i])){
			digitCount++;
			if (matrix[i+1] == '\0'){
				for (int j = 0; j < digitCount; j++){
					number = number + (((int)(matrix[i-j]-'0')))*(pow(10,j));
					numberArray[numArrayIndex] = number;
				}
			}
		}
		else if (digitCount != 0) {
			for (int j = 1; j <= digitCount; j++){
				number = number + (((int)(matrix[i-j]-'0')))*(pow(10,(j-1)));
			}
			numberArray[numArrayIndex] = number;
			numArrayIndex++;
			number = 0;
			digitCount = 0;
		}
	}
}

void matrix_multiplication(int **matrixA, int **matrixB, int **matrixAB, int ABrows, int ABcols, int sumTimes){
	for (int row = 0; row < ABrows; row++){
		for (int col = 0; col < ABcols; col++){
			for (int i = 0; i < sumTimes; i++)
				matrixAB[row][col] =  matrixAB[row][col] + matrixA[row][i]*matrixB[i][col];
		}
	}
}